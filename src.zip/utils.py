
"""
utility functions for nfl wide receiver rookie prediction analysis
provides standardized column mapping, data cleaning helpers, and plotting configurations
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# set consistent plotting style
plt.style.use('default')
sns.set_palette("husl")

def setup_plotting_style():
    """configure matplotlib and seaborn for consistent figure appearance"""
    plt.rcParams.update({
        'figure.figsize': (10, 6),
        'font.size': 10,
        'axes.titlesize': 12,
        'axes.labelsize': 10,
        'xtick.labelsize': 9,
        'ytick.labelsize': 9,
        'legend.fontsize': 9,
        'figure.dpi': 100,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight'
    })

def standardize_player_name(name: str) -> str:
    """clean and standardize player names for consistent matching"""
    if pd.isna(name):
        return ""
    
    # remove common suffixes and clean formatting
    name = str(name).strip()
    suffixes = [' Jr.', ' Sr.', ' III', ' II', ' IV']
    for suffix in suffixes:
        name = name.replace(suffix, '')
    
    # handle special characters and formatting
    name = name.replace('.', '').replace("'", "").replace('-', ' ')
    
    # standardize spacing
    name = ' '.join(name.split())
    
    return name.title()

def standardize_team_name(team: str) -> str:
    """standardize team abbreviations across different data sources"""
    if pd.isna(team):
        return ""
    
    team_mapping = {
        'LAR': 'LA', 'LV': 'LVR', 'WSH': 'WAS', 'JAX': 'JAC',
        'TB': 'TAM', 'NE': 'NEP', 'NO': 'NOR', 'SF': 'SFO',
        'KC': 'KAN', 'GB': 'GNB'
    }
    
    team = str(team).upper().strip()
    return team_mapping.get(team, team)

def get_column_mapping() -> Dict[str, str]:
    """return standardized column name mapping for consistent data processing"""
    return {
        # player identification
        'player': 'player_name',
        'Player': 'player_name',
        'player_name': 'player_name',
        
        # team information
        'team_name': 'team',
        'Tm': 'team',
        'team': 'team',
        
        # basic stats
        'receptions': 'rec',
        'Rec': 'rec',
        'receiving_yards': 'rec_yards',
        'yards': 'rec_yards',
        'Yds': 'rec_yards',
        'receiving_tds': 'rec_td',
        'touchdowns': 'rec_td',
        'TD': 'rec_td',
        'targets': 'targets',
        'Targets': 'targets',
        
        # draft information
        'Rnd': 'draft_round',
        'Pick': 'draft_pick',
        'draft_round': 'draft_round',
        'draft_pick': 'draft_pick',
        
        # advanced metrics
        'routes': 'routes_run',
        'RouteParticipation': 'route_participation',
        'TargetShare': 'target_share',
        'AirYards': 'air_yards',
        'yards_after_catch': 'yac',
        'contested_catch_rate': 'contested_catch_pct',
        
        # age and experience
        'Age': 'age',
        'age': 'age',
        'rookie_year': 'rookie_year',
        'Rookie year': 'rookie_year'
    }

def clean_numeric_column(series: pd.Series, fill_value: float = 0.0) -> pd.Series:
    """clean numeric columns by handling missing values and converting data types"""
    # convert to numeric, coercing errors to nan
    numeric_series = pd.to_numeric(series, errors='coerce')
    
    # fill missing values
    numeric_series = numeric_series.fillna(fill_value)
    
    return numeric_series

def detect_outliers_iqr(series: pd.Series, multiplier: float = 1.5) -> pd.Series:
    """detect outliers using interquartile range method"""
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    
    lower_bound = q1 - multiplier * iqr
    upper_bound = q3 + multiplier * iqr
    
    return (series < lower_bound) | (series > upper_bound)

def create_draft_capital_tiers(draft_pick: pd.Series) -> pd.Series:
    """create draft capital tiers based on draft position"""
    def assign_tier(pick):
        if pd.isna(pick):
            return 'undrafted'
        elif pick <= 32:
            return 'round_1'
        elif pick <= 64:
            return 'round_2'
        elif pick <= 96:
            return 'round_3'
        elif pick <= 160:
            return 'rounds_4_5'
        else:
            return 'rounds_6_7'
    
    return draft_pick.apply(assign_tier)

def calculate_age_adjusted_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """calculate age-adjusted performance metrics"""
    df = df.copy()
    
    if 'age' in df.columns and 'rec_yards' in df.columns:
        # typical rookie age is around 22
        age_adjustment = (22 - df['age']) * 0.05
        df['age_adj_rec_yards'] = df['rec_yards'] * (1 + age_adjustment)
    
    if 'age' in df.columns and 'rec' in df.columns:
        age_adjustment = (22 - df['age']) * 0.05
        df['age_adj_receptions'] = df['rec'] * (1 + age_adjustment)
    
    return df

def save_figure(fig, filename: str, directory: str = '/home/ubuntu/figs'):
    """save matplotlib figure with consistent formatting"""
    filepath = f"{directory}/{filename}"
    fig.savefig(filepath, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"saved figure: {filepath}")

def print_data_summary(df: pd.DataFrame, title: str = "data summary"):
    """print comprehensive data summary statistics"""
    print(f"\n{'='*50}")
    print(f"{title.upper()}")
    print(f"{'='*50}")
    print(f"shape: {df.shape}")
    print(f"memory usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} mb")
    print(f"\nmissing values:")
    missing = df.isnull().sum()
    missing_pct = (missing / len(df)) * 100
    missing_df = pd.DataFrame({
        'missing_count': missing,
        'missing_percent': missing_pct
    }).sort_values('missing_count', ascending=False)
    print(missing_df[missing_df['missing_count'] > 0])
    
    print(f"\ndata types:")
    print(df.dtypes.value_counts())
    
    if len(df) > 0:
        print(f"\nnumeric columns summary:")
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            print(df[numeric_cols].describe())

# initialize plotting style when module is imported
setup_plotting_style()
