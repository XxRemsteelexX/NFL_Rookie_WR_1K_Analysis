
"""
advanced feature engineering module for nfl wide receiver rookie prediction
creates sophisticated features including efficiency metrics, contextual variables, and interaction terms
"""

import pandas as pd
import numpy as np
import sys
sys.path.append('/home/ubuntu')
from typing import List, Dict, Tuple
import warnings
warnings.filterwarnings('ignore')

from src.utils import (
    create_draft_capital_tiers, calculate_age_adjusted_metrics, 
    clean_numeric_column, print_data_summary
)

def load_cleaned_data() -> pd.DataFrame:
    """load the cleaned dataset from parquet file"""
    try:
        df = pd.read_parquet('/home/ubuntu/outputs/cleaned_dataset.parquet')
        print(f"loaded cleaned dataset: {df.shape}")
        return df
    except Exception as e:
        print(f"error loading cleaned dataset: {e}")
        return pd.DataFrame()

def create_efficiency_features(df: pd.DataFrame) -> pd.DataFrame:
    """create advanced efficiency and rate-based features"""
    print("creating efficiency features...")
    
    df_eng = df.copy()
    
    # receiving efficiency metrics
    if 'rec_yards' in df_eng.columns and 'targets' in df_eng.columns:
        df_eng['yards_per_target'] = np.where(
            df_eng['targets'] > 0,
            df_eng['rec_yards'] / df_eng['targets'],
            0
        )
    
    if 'rec_yards' in df_eng.columns and 'routes_run' in df_eng.columns:
        df_eng['yards_per_route_run'] = np.where(
            df_eng['routes_run'] > 0,
            df_eng['rec_yards'] / df_eng['routes_run'],
            0
        )
    
    # target efficiency
    if 'targets' in df_eng.columns and 'routes_run' in df_eng.columns:
        df_eng['target_rate'] = np.where(
            df_eng['routes_run'] > 0,
            df_eng['targets'] / df_eng['routes_run'],
            0
        )
    
    # touchdown efficiency
    if 'rec_td' in df_eng.columns and 'rec' in df_eng.columns:
        df_eng['td_per_reception'] = np.where(
            df_eng['rec'] > 0,
            df_eng['rec_td'] / df_eng['rec'],
            0
        )
    
    if 'rec_td' in df_eng.columns and 'targets' in df_eng.columns:
        df_eng['td_per_target'] = np.where(
            df_eng['targets'] > 0,
            df_eng['rec_td'] / df_eng['targets'],
            0
        )
    
    # red zone efficiency (if available)
    if 'RedZoneTargets' in df_eng.columns and 'rec_td' in df_eng.columns:
        df_eng['rz_td_rate'] = np.where(
            df_eng['RedZoneTargets'] > 0,
            df_eng['rec_td'] / df_eng['RedZoneTargets'],
            0
        )
    
    # air yards efficiency
    if 'air_yards' in df_eng.columns and 'targets' in df_eng.columns:
        df_eng['air_yards_per_target'] = np.where(
            df_eng['targets'] > 0,
            df_eng['air_yards'] / df_eng['targets'],
            0
        )
    
    # yards after catch efficiency
    if 'yac' in df_eng.columns and 'rec' in df_eng.columns:
        df_eng['yac_per_reception'] = np.where(
            df_eng['rec'] > 0,
            df_eng['yac'] / df_eng['rec'],
            0
        )
    
    print(f"efficiency features created, new shape: {df_eng.shape}")
    return df_eng

def create_draft_capital_features(df: pd.DataFrame) -> pd.DataFrame:
    """create advanced draft capital and positional features"""
    print("creating draft capital features...")
    
    df_eng = df.copy()
    
    # draft capital tiers
    if 'draft_pick' in df_eng.columns:
        df_eng['draft_tier'] = create_draft_capital_tiers(df_eng['draft_pick'])
        
        # draft capital score (inverse of pick number, normalized)
        max_pick = df_eng['draft_pick'].max()
        df_eng['draft_capital_score'] = np.where(
            df_eng['draft_pick'] > 0,
            (max_pick - df_eng['draft_pick'] + 1) / max_pick,
            0  # undrafted players get 0
        )
        
        # early round indicator
        df_eng['early_round'] = (df_eng['draft_round'] <= 2).astype(int)
        df_eng['first_round'] = (df_eng['draft_round'] == 1).astype(int)
        df_eng['day_1_pick'] = (df_eng['draft_pick'] <= 32).astype(int)
        df_eng['day_2_pick'] = ((df_eng['draft_pick'] > 32) & (df_eng['draft_pick'] <= 96)).astype(int)
        
        # positional draft ranking (within wr class)
        if 'rookie_year' in df_eng.columns:
            df_eng['wr_draft_rank'] = df_eng.groupby('rookie_year')['draft_pick'].rank(method='min')
            df_eng['top_3_wr'] = (df_eng['wr_draft_rank'] <= 3).astype(int)
            df_eng['top_5_wr'] = (df_eng['wr_draft_rank'] <= 5).astype(int)
    
    print(f"draft capital features created, new shape: {df_eng.shape}")
    return df_eng

def create_contextual_features(df: pd.DataFrame) -> pd.DataFrame:
    """create contextual features based on team, era, and situation"""
    print("creating contextual features...")
    
    df_eng = df.copy()
    
    # era-based features
    if 'rookie_year' in df_eng.columns:
        # modern era (2011+) with more passing
        df_eng['modern_era'] = (df_eng['rookie_year'] >= 2011).astype(int)
        df_eng['recent_era'] = (df_eng['rookie_year'] >= 2018).astype(int)
        
        # era-adjusted performance metrics
        era_adjustment = np.where(df_eng['rookie_year'] >= 2011, 1.0, 1.15)  # adjust for era
        
        if 'rec_yards' in df_eng.columns:
            df_eng['era_adj_rec_yards'] = df_eng['rec_yards'] * era_adjustment
        if 'targets' in df_eng.columns:
            df_eng['era_adj_targets'] = df_eng['targets'] * era_adjustment
    
    # age-based features
    if 'age' in df_eng.columns:
        df_eng['young_rookie'] = (df_eng['age'] <= 21).astype(int)
        df_eng['old_rookie'] = (df_eng['age'] >= 24).astype(int)
        
        # age-adjusted metrics
        df_eng = calculate_age_adjusted_metrics(df_eng)
    
    # opportunity and usage features
    if 'targets' in df_eng.columns and 'rookie_year' in df_eng.columns:
        # calculate percentile within rookie class
        df_eng['target_percentile'] = df_eng.groupby('rookie_year')['targets'].rank(pct=True)
        df_eng['high_target_rookie'] = (df_eng['target_percentile'] >= 0.8).astype(int)
    
    if 'rec_yards' in df_eng.columns and 'rookie_year' in df_eng.columns:
        df_eng['yards_percentile'] = df_eng.groupby('rookie_year')['rec_yards'].rank(pct=True)
        df_eng['high_yards_rookie'] = (df_eng['yards_percentile'] >= 0.8).astype(int)
    
    # snap share and route participation features
    if 'route_participation' in df_eng.columns:
        df_eng['high_route_participation'] = (df_eng['route_participation'] >= 70).astype(int)
        df_eng['low_route_participation'] = (df_eng['route_participation'] <= 40).astype(int)
    
    print(f"contextual features created, new shape: {df_eng.shape}")
    return df_eng

def create_production_thresholds(df: pd.DataFrame) -> pd.DataFrame:
    """create binary threshold features for key production metrics"""
    print("creating production threshold features...")
    
    df_eng = df.copy()
    
    # receiving yards thresholds
    if 'rec_yards' in df_eng.columns:
        df_eng['yards_300_plus'] = (df_eng['rec_yards'] >= 300).astype(int)
        df_eng['yards_500_plus'] = (df_eng['rec_yards'] >= 500).astype(int)
        df_eng['yards_700_plus'] = (df_eng['rec_yards'] >= 700).astype(int)
        df_eng['yards_1000_plus'] = (df_eng['rec_yards'] >= 1000).astype(int)
    
    # reception thresholds
    if 'rec' in df_eng.columns:
        df_eng['rec_30_plus'] = (df_eng['rec'] >= 30).astype(int)
        df_eng['rec_50_plus'] = (df_eng['rec'] >= 50).astype(int)
        df_eng['rec_70_plus'] = (df_eng['rec'] >= 70).astype(int)
    
    # target thresholds
    if 'targets' in df_eng.columns:
        df_eng['targets_50_plus'] = (df_eng['targets'] >= 50).astype(int)
        df_eng['targets_80_plus'] = (df_eng['targets'] >= 80).astype(int)
        df_eng['targets_100_plus'] = (df_eng['targets'] >= 100).astype(int)
    
    # touchdown thresholds
    if 'rec_td' in df_eng.columns:
        df_eng['td_3_plus'] = (df_eng['rec_td'] >= 3).astype(int)
        df_eng['td_5_plus'] = (df_eng['rec_td'] >= 5).astype(int)
    
    # efficiency thresholds
    if 'yards_per_reception' in df_eng.columns:
        df_eng['ypr_12_plus'] = (df_eng['yards_per_reception'] >= 12).astype(int)
        df_eng['ypr_15_plus'] = (df_eng['yards_per_reception'] >= 15).astype(int)
    
    if 'catch_rate' in df_eng.columns:
        df_eng['catch_rate_65_plus'] = (df_eng['catch_rate'] >= 0.65).astype(int)
        df_eng['catch_rate_70_plus'] = (df_eng['catch_rate'] >= 0.70).astype(int)
    
    print(f"production threshold features created, new shape: {df_eng.shape}")
    return df_eng

def create_interaction_features(df: pd.DataFrame) -> pd.DataFrame:
    """create interaction features between key variables"""
    print("creating interaction features...")
    
    df_eng = df.copy()
    
    # draft position x performance interactions
    if 'draft_capital_score' in df_eng.columns and 'rec_yards' in df_eng.columns:
        df_eng['draft_x_yards'] = df_eng['draft_capital_score'] * df_eng['rec_yards']
    
    if 'early_round' in df_eng.columns and 'targets' in df_eng.columns:
        df_eng['early_round_x_targets'] = df_eng['early_round'] * df_eng['targets']
    
    # age x performance interactions
    if 'age' in df_eng.columns and 'rec_yards' in df_eng.columns:
        df_eng['age_x_yards'] = df_eng['age'] * df_eng['rec_yards']
    
    if 'young_rookie' in df_eng.columns and 'yards_per_target' in df_eng.columns:
        df_eng['young_x_efficiency'] = df_eng['young_rookie'] * df_eng['yards_per_target']
    
    # volume x efficiency interactions
    if 'targets' in df_eng.columns and 'catch_rate' in df_eng.columns:
        df_eng['volume_x_efficiency'] = df_eng['targets'] * df_eng['catch_rate']
    
    if 'rec' in df_eng.columns and 'yards_per_reception' in df_eng.columns:
        df_eng['rec_x_ypr'] = df_eng['rec'] * df_eng['yards_per_reception']
    
    # era x performance interactions
    if 'modern_era' in df_eng.columns and 'rec_yards' in df_eng.columns:
        df_eng['modern_era_x_yards'] = df_eng['modern_era'] * df_eng['rec_yards']
    
    # opportunity x production interactions
    if 'route_participation' in df_eng.columns and 'yards_per_route_run' in df_eng.columns:
        df_eng['opportunity_x_efficiency'] = df_eng['route_participation'] * df_eng['yards_per_route_run']
    
    print(f"interaction features created, new shape: {df_eng.shape}")
    return df_eng

def create_composite_scores(df: pd.DataFrame) -> pd.DataFrame:
    """create composite scores combining multiple metrics"""
    print("creating composite scores...")
    
    df_eng = df.copy()
    
    # rookie production score
    production_features = ['rec', 'rec_yards', 'rec_td', 'targets']
    available_production = [col for col in production_features if col in df_eng.columns]
    
    if len(available_production) >= 3:
        # normalize each feature to 0-1 scale
        production_normalized = df_eng[available_production].copy()
        for col in available_production:
            max_val = production_normalized[col].max()
            if max_val > 0:
                production_normalized[col] = production_normalized[col] / max_val
        
        # weighted composite score
        weights = {'rec': 0.25, 'rec_yards': 0.4, 'rec_td': 0.2, 'targets': 0.15}
        df_eng['rookie_production_score'] = 0
        
        for col in available_production:
            weight = weights.get(col, 1.0 / len(available_production))
            df_eng['rookie_production_score'] += production_normalized[col] * weight
    
    # efficiency composite score
    efficiency_features = ['catch_rate', 'yards_per_reception', 'yards_per_target', 'td_per_reception']
    available_efficiency = [col for col in efficiency_features if col in df_eng.columns]
    
    if len(available_efficiency) >= 2:
        efficiency_normalized = df_eng[available_efficiency].copy()
        for col in available_efficiency:
            max_val = efficiency_normalized[col].max()
            if max_val > 0:
                efficiency_normalized[col] = efficiency_normalized[col] / max_val
        
        df_eng['efficiency_score'] = efficiency_normalized.mean(axis=1)
    
    # draft-adjusted production score
    if 'rookie_production_score' in df_eng.columns and 'draft_capital_score' in df_eng.columns:
        df_eng['draft_adj_production'] = df_eng['rookie_production_score'] / (df_eng['draft_capital_score'] + 0.1)
    
    # breakout candidate score
    breakout_features = []
    if 'yards_500_plus' in df_eng.columns:
        breakout_features.append('yards_500_plus')
    if 'targets_80_plus' in df_eng.columns:
        breakout_features.append('targets_80_plus')
    if 'catch_rate_65_plus' in df_eng.columns:
        breakout_features.append('catch_rate_65_plus')
    if 'early_round' in df_eng.columns:
        breakout_features.append('early_round')
    if 'young_rookie' in df_eng.columns:
        breakout_features.append('young_rookie')
    
    if len(breakout_features) >= 3:
        df_eng['breakout_score'] = df_eng[breakout_features].sum(axis=1) / len(breakout_features)
    
    print(f"composite scores created, new shape: {df_eng.shape}")
    return df_eng

def create_statistical_features(df: pd.DataFrame) -> pd.DataFrame:
    """create statistical transformation features"""
    print("creating statistical features...")
    
    df_eng = df.copy()
    
    # log transformations for skewed variables
    skewed_vars = ['rec_yards', 'rec', 'targets', 'air_yards']
    
    for var in skewed_vars:
        if var in df_eng.columns:
            # add small constant to handle zeros
            df_eng[f'{var}_log'] = np.log1p(df_eng[var])
    
    # square root transformations
    for var in skewed_vars:
        if var in df_eng.columns:
            df_eng[f'{var}_sqrt'] = np.sqrt(df_eng[var])
    
    # polynomial features for key metrics
    key_metrics = ['rec_yards', 'targets', 'catch_rate']
    
    for metric in key_metrics:
        if metric in df_eng.columns:
            df_eng[f'{metric}_squared'] = df_eng[metric] ** 2
    
    # standardized features (z-scores within rookie class)
    if 'rookie_year' in df_eng.columns:
        standardize_vars = ['rec_yards', 'rec', 'targets', 'yards_per_reception']
        
        for var in standardize_vars:
            if var in df_eng.columns:
                df_eng[f'{var}_zscore'] = df_eng.groupby('rookie_year')[var].transform(
                    lambda x: (x - x.mean()) / (x.std() + 1e-8)
                )
    
    print(f"statistical features created, new shape: {df_eng.shape}")
    return df_eng

def select_final_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    """select final feature set and prepare target variable"""
    print("selecting final features...")
    
    # define feature categories
    base_features = [
        'draft_round', 'draft_pick', 'age', 'rec', 'rec_yards', 'rec_td', 'targets'
    ]
    
    efficiency_features = [
        'catch_rate', 'yards_per_reception', 'yards_per_target', 'yards_per_route_run',
        'target_rate', 'td_per_reception', 'yac_per_reception'
    ]
    
    draft_features = [
        'draft_capital_score', 'early_round', 'first_round', 'day_1_pick', 
        'wr_draft_rank', 'top_3_wr', 'top_5_wr'
    ]
    
    contextual_features = [
        'modern_era', 'recent_era', 'young_rookie', 'old_rookie',
        'target_percentile', 'yards_percentile', 'high_target_rookie'
    ]
    
    threshold_features = [
        'yards_500_plus', 'rec_50_plus', 'targets_80_plus', 'td_3_plus',
        'catch_rate_65_plus', 'ypr_12_plus'
    ]
    
    interaction_features = [
        'draft_x_yards', 'early_round_x_targets', 'volume_x_efficiency',
        'modern_era_x_yards', 'opportunity_x_efficiency'
    ]
    
    composite_features = [
        'rookie_production_score', 'efficiency_score', 'breakout_score'
    ]
    
    statistical_features = [
        'rec_yards_log', 'targets_log', 'rec_yards_sqrt', 'rec_yards_zscore'
    ]
    
    # combine all feature categories
    all_feature_categories = [
        base_features, efficiency_features, draft_features, contextual_features,
        threshold_features, interaction_features, composite_features, statistical_features
    ]
    
    # select available features
    selected_features = []
    for category in all_feature_categories:
        available_in_category = [col for col in category if col in df.columns]
        selected_features.extend(available_in_category)
    
    # remove duplicates while preserving order
    selected_features = list(dict.fromkeys(selected_features))
    
    print(f"selected {len(selected_features)} features from {df.shape[1]} total columns")
    
    # prepare feature matrix
    X = df[selected_features].copy()
    
    # prepare target variable
    if 'has_1000_yard_season' in df.columns:
        y = df['has_1000_yard_season'].copy()
    else:
        print("warning: target variable not found, creating dummy target")
        y = pd.Series(0, index=df.index)
    
    # handle missing values in features
    for col in X.columns:
        if X[col].dtype in ['float64', 'int64']:
            X[col] = X[col].fillna(0)
        else:
            X[col] = X[col].fillna('unknown')
    
    print(f"final feature matrix shape: {X.shape}")
    print(f"target variable distribution: {y.value_counts().to_dict()}")
    
    return X, y

def create_feature_documentation(X: pd.DataFrame):
    """create documentation for engineered features"""
    print("creating feature documentation...")
    
    # categorize features
    feature_categories = {
        'base_stats': ['rec', 'rec_yards', 'rec_td', 'targets', 'age'],
        'draft_info': ['draft_round', 'draft_pick', 'draft_capital_score', 'early_round', 'first_round'],
        'efficiency': ['catch_rate', 'yards_per_reception', 'yards_per_target', 'target_rate'],
        'thresholds': [col for col in X.columns if any(thresh in col for thresh in ['_plus', '_rate_'])],
        'interactions': [col for col in X.columns if '_x_' in col],
        'composites': [col for col in X.columns if 'score' in col],
        'transformations': [col for col in X.columns if any(trans in col for trans in ['_log', '_sqrt', '_zscore'])]
    }
    
    doc_lines = []
    doc_lines.append("# feature engineering documentation\n\n")
    doc_lines.append("## feature categories and descriptions\n\n")
    
    for category, features in feature_categories.items():
        available_features = [f for f in features if f in X.columns]
        if available_features:
            doc_lines.append(f"### {category.replace('_', ' ').title()}\n")
            for feature in available_features:
                doc_lines.append(f"- **{feature}**: {get_feature_description(feature)}\n")
            doc_lines.append("\n")
    
    # feature statistics
    doc_lines.append("## feature statistics\n\n")
    doc_lines.append(f"- **total features**: {len(X.columns)}\n")
    doc_lines.append(f"- **numeric features**: {len(X.select_dtypes(include=[np.number]).columns)}\n")
    doc_lines.append(f"- **categorical features**: {len(X.select_dtypes(include=['object']).columns)}\n")
    
    # missing value summary
    missing_summary = X.isnull().sum()
    missing_features = missing_summary[missing_summary > 0]
    
    if len(missing_features) > 0:
        doc_lines.append("\n## features with missing values\n\n")
        for feature, count in missing_features.items():
            pct = count / len(X) * 100
            doc_lines.append(f"- **{feature}**: {count} ({pct:.1f}%)\n")
    
    # save documentation
    doc_path = '/home/ubuntu/outputs/feature_documentation.md'
    with open(doc_path, 'w') as f:
        f.writelines(doc_lines)
    
    print(f"feature documentation saved to: {doc_path}")

def get_feature_description(feature_name: str) -> str:
    """get description for a feature based on its name"""
    descriptions = {
        'rec': 'total receptions in rookie season',
        'rec_yards': 'total receiving yards in rookie season',
        'rec_td': 'total receiving touchdowns in rookie season',
        'targets': 'total targets in rookie season',
        'catch_rate': 'receptions divided by targets',
        'yards_per_reception': 'receiving yards divided by receptions',
        'yards_per_target': 'receiving yards divided by targets',
        'draft_capital_score': 'normalized draft position score (higher = earlier pick)',
        'early_round': 'drafted in rounds 1-2 (binary)',
        'rookie_production_score': 'weighted composite of rookie production metrics',
        'efficiency_score': 'composite efficiency rating',
        'breakout_score': 'probability of future breakout based on rookie indicators'
    }
    
    # check for pattern matches
    if '_plus' in feature_name:
        threshold = feature_name.split('_')[-2]
        metric = feature_name.replace(f'_{threshold}_plus', '')
        return f'achieved {threshold}+ {metric.replace("_", " ")} in rookie season (binary)'
    
    if '_x_' in feature_name:
        parts = feature_name.split('_x_')
        return f'interaction between {parts[0].replace("_", " ")} and {parts[1].replace("_", " ")}'
    
    if '_log' in feature_name:
        base = feature_name.replace('_log', '')
        return f'log transformation of {base.replace("_", " ")}'
    
    if '_sqrt' in feature_name:
        base = feature_name.replace('_sqrt', '')
        return f'square root transformation of {base.replace("_", " ")}'
    
    if '_zscore' in feature_name:
        base = feature_name.replace('_zscore', '')
        return f'z-score normalized {base.replace("_", " ")} within rookie class'
    
    return descriptions.get(feature_name, 'engineered feature')

def main():
    """main function to execute feature engineering pipeline"""
    print("starting advanced feature engineering")
    print("="*50)
    
    # load cleaned data
    df = load_cleaned_data()
    
    if df.empty:
        print("no data available for feature engineering")
        return
    
    # apply feature engineering steps
    df_eng = create_efficiency_features(df)
    df_eng = create_draft_capital_features(df_eng)
    df_eng = create_contextual_features(df_eng)
    df_eng = create_production_thresholds(df_eng)
    df_eng = create_interaction_features(df_eng)
    df_eng = create_composite_scores(df_eng)
    df_eng = create_statistical_features(df_eng)
    
    # select final features and prepare target
    X, y = select_final_features(df_eng)
    
    # save engineered features and target
    X.to_parquet('/home/ubuntu/outputs/features_X.parquet', index=False)
    y.to_frame('target').to_parquet('/home/ubuntu/outputs/target_y.parquet', index=False)
    
    print(f"\nfeatures saved to: /home/ubuntu/outputs/features_X.parquet")
    print(f"target saved to: /home/ubuntu/outputs/target_y.parquet")
    
    # create feature documentation
    create_feature_documentation(X)
    
    # print summary
    print_data_summary(X, "engineered features")
    
    print("\nfeature engineering completed successfully!")

if __name__ == "__main__":
    main()
